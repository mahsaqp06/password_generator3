# -*- coding: utf-8 -*-
"""
مدیریت رمز عبور آفلاین - رابط خط فرمان (CLI)

اجرا با دستور:  python main.py
"""

import getpass

from generator import PasswordGenerator
from password_manager import PasswordManager


def print_menu():
    print("\n=== مدیریت رمز عبور آفلاین ===")
    print("۱. افزودن رکورد جدید")
    print("۲. نمایش همه‌ی رکوردها")
    print("۳. جست‌وجو بر اساس عنوان")
    print("۴. تغییر یک رمز عبور")
    print("۵. حذف یک رکورد")
    print("۶. ساخت رمز عبور تصادفی")
    print("۷. خروج")


def ask_generated_password(generator: PasswordGenerator) -> str:
    """از کاربر تنظیمات رمز عبور تصادفی را می‌پرسد و آن را می‌سازد."""
    length_input = input("طول رمز عبور (پیش‌فرض ۱۶): ").strip()
    length = int(length_input) if length_input else 16

    use_symbols = input("استفاده از نمادها مثل !@# ؟ (y/n, پیش‌فرض y): ").strip().lower()
    use_symbols = use_symbols != "n"

    password = generator.generate(length=length, use_symbols=use_symbols)
    print(f"رمز عبور ساخته‌شده: {password}")
    return password


def print_entry(entry, show_password=False):
    pwd = entry.password if show_password else "*" * len(entry.password)
    print(
        f"- [{entry.id[:8]}] {entry.title} | نام کاربری: {entry.username} "
        f"| رمز عبور: {pwd} | تاریخ ثبت: {entry.created_at}"
    )


def main():
    print("به برنامه‌ی مدیریت رمز عبور آفلاین خوش آمدید.")
    manager = PasswordManager()
    generator = PasswordGenerator()

    if manager.vault_exists():
        master = getpass.getpass("رمز عبور اصلی خود را وارد کنید: ")
    else:
        print("هنوز صندوقچه‌ای ساخته نشده -- بیایید یکی بسازیم.")
        master = getpass.getpass("یک رمز عبور اصلی انتخاب کنید: ")

    try:
        manager.unlock(master)
    except ValueError as exc:
        print(f"خطا: {exc}")
        return

    while True:
        print_menu()
        choice = input("یک گزینه را انتخاب کنید: ").strip()

        if choice == "1" or choice == "۱":
            title = input("عنوان (مثال: Gmail): ").strip()
            username = input("نام کاربری/ایمیل: ").strip()

            gen_choice = input("رمز عبور تصادفی ساخته شود؟ (y/n): ").strip().lower()
            if gen_choice == "y":
                try:
                    password = ask_generated_password(generator)
                except ValueError as exc:
                    print(f"خطا: {exc}")
                    continue
            else:
                password = getpass.getpass("رمز عبور: ")

            try:
                manager.add_entry(title, username, password)
                print("رکورد ذخیره شد.")
            except ValueError as exc:
                print(f"خطا: {exc}")

        elif choice == "2" or choice == "۲":
            entries = manager.list_entries()
            if not entries:
                print("صندوقچه خالی است.")
            for e in entries:
                print_entry(e)

        elif choice == "3" or choice == "۳":
            query = input("عنوان مورد جست‌وجو: ").strip()
            results = manager.find_by_title(query)
            if not results:
                print("موردی پیدا نشد.")
            for e in results:
                print_entry(e)

        elif choice == "4" or choice == "۴":
            entry_id_prefix = input("شناسه‌ی رکورد (۸ کاراکتر اول، از لیست): ").strip()
            match = next(
                (e for e in manager.list_entries() if e.id.startswith(entry_id_prefix)),
                None,
            )
            if not match:
                print("رکورد پیدا نشد.")
                continue

            gen_choice = input("رمز عبور تصادفی ساخته شود؟ (y/n): ").strip().lower()
            if gen_choice == "y":
                try:
                    new_password = ask_generated_password(generator)
                except ValueError as exc:
                    print(f"خطا: {exc}")
                    continue
            else:
                new_password = getpass.getpass("رمز عبور جدید: ")

            try:
                manager.update_password(match.id, new_password)
                print("رمز عبور به‌روزرسانی شد.")
            except ValueError as exc:
                print(f"خطا: {exc}")

        elif choice == "5" or choice == "۵":
            entry_id_prefix = input("شناسه‌ی رکورد (۸ کاراکتر اول، از لیست): ").strip()
            match = next(
                (e for e in manager.list_entries() if e.id.startswith(entry_id_prefix)),
                None,
            )
            if not match:
                print("رکورد پیدا نشد.")
                continue
            manager.delete_entry(match.id)
            print("رکورد حذف شد.")

        elif choice == "6" or choice == "۶":
            try:
                ask_generated_password(generator)
                print("(این رمز عبور فقط نمایش داده شد و در جایی ذخیره نشد.)")
            except ValueError as exc:
                print(f"خطا: {exc}")

        elif choice == "7" or choice == "۷":
            print("خدانگهدار!")
            break

        else:
            print("گزینه‌ی نامعتبر است، دوباره تلاش کنید.")


if __name__ == "__main__":
    main()

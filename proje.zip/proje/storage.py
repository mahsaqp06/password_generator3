"""
لایه‌ی ذخیره‌سازی، به شکل الگوی طراحی Singleton پیاده‌سازی شده است.

یک پسورد منیجر باید فقط یک نقطه‌ی ارتباط با فایل صندوقچه روی دیسک داشته
باشد -- در غیر این صورت ممکن است دو بخش از برنامه داده‌ی قدیمی بخوانند یا
تغییرات یکدیگر را از بین ببرند. الگوی Singleton (که در جلسه‌ی الگوهای
طراحی دیدیم) تضمین می‌کند که هر جای برنامه Storage() صدا زده شود، همیشه
همان یک نمونه‌ی مشترک برگردانده می‌شود.
"""

import json
import os
from typing import List

from crypto_utils import decrypt, derive_key, encrypt, generate_salt

DATA_FILE = "vault.dat"
SALT_FILE = "vault.salt"


class Storage:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, data_dir: str = "."):
        if self._initialized:
            return
        self._data_dir = data_dir
        self._data_path = os.path.join(data_dir, DATA_FILE)
        self._salt_path = os.path.join(data_dir, SALT_FILE)
        self._key = None
        self._initialized = True

    # -- مدیریت رمز عبور اصلی و کلید -------------------------------
    def unlock(self, master_password: str) -> None:
        """باز کردن صندوقچه با رمز عبور اصلی (کلید رمزنگاری را می‌سازد)."""
        salt = self._load_or_create_salt()
        self._key = derive_key(master_password, salt)

    def vault_exists(self) -> bool:
        """آیا فایل صندوقچه از قبل روی دیسک وجود دارد؟"""
        return os.path.exists(self._data_path)

    def _load_or_create_salt(self) -> bytes:
        if os.path.exists(self._salt_path):
            with open(self._salt_path, "rb") as f:
                return f.read()
        salt = generate_salt()
        with open(self._salt_path, "wb") as f:
            f.write(salt)
        return salt

    # -- خواندن / نوشتن -----------------------------------------------
    def load_entries(self) -> List[dict]:
        """خواندن و رمزگشایی رکوردها از فایل صندوقچه."""
        if not self.vault_exists():
            return []
        with open(self._data_path, "rb") as f:
            token = f.read()
        try:
            raw = decrypt(token, self._key)
        except Exception as exc:
            raise ValueError("رمز عبور اصلی اشتباه است یا صندوقچه خراب شده.") from exc
        return json.loads(raw.decode("utf-8"))

    def save_entries(self, entries: List[dict]) -> None:
        """رمزگذاری و ذخیره‌ی رکوردها روی دیسک."""
        raw = json.dumps(entries, ensure_ascii=False, indent=2).encode("utf-8")
        token = encrypt(raw, self._key)
        with open(self._data_path, "wb") as f:
            f.write(token)

"""
ماژول کمکی برای تبدیل رمز عبور اصلی (master password) به یک کلید رمزنگاری
و همچنین رمزگذاری / رمزگشایی فایل صندوقچه (vault).

از PBKDF2 (برای تولید کلید) و Fernet (رمزنگاری متقارن) از کتابخانه‌ی
استاندارد cryptography استفاده شده است.
"""

import base64
import os

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

SALT_SIZE = 16
KDF_ITERATIONS = 200_000


def generate_salt() -> bytes:
    """ساخت یک salt تصادفی جدید برای یک صندوقچه‌ی تازه."""
    return os.urandom(SALT_SIZE)


def derive_key(master_password: str, salt: bytes) -> bytes:
    """تبدیل رمز عبور اصلی + salt به یک کلید سازگار با Fernet."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=KDF_ITERATIONS,
    )
    key = kdf.derive(master_password.encode("utf-8"))
    return base64.urlsafe_b64encode(key)


def encrypt(data: bytes, key: bytes) -> bytes:
    """رمزگذاری داده با کلید داده‌شده."""
    return Fernet(key).encrypt(data)


def decrypt(token: bytes, key: bytes) -> bytes:
    """رمزگشایی داده با کلید داده‌شده."""
    return Fernet(key).decrypt(token)

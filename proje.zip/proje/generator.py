# -*- coding: utf-8 -*-
"""
تولیدکننده‌ی رمز عبور تصادفی و امن.

از ماژول استاندارد `secrets` استفاده شده که برای اهداف رمزنگاری امن است
(بر خلاف ماژول `random` که برای این‌کار مناسب نیست).
"""

import secrets
import string


class PasswordGenerator:
    """کالسی برای ساخت رمزهای عبور تصادفی و قوی."""

    LOWER = string.ascii_lowercase
    UPPER = string.ascii_uppercase
    DIGITS = string.digits
    SYMBOLS = "!@#$%^&*()-_=+[]{}?"

    def generate(
        self,
        length: int = 16,
        use_upper: bool = True,
        use_lower: bool = True,
        use_digits: bool = True,
        use_symbols: bool = True,
    ) -> str:
        """ساخت یک رمز عبور تصادفی بر اساس تنظیمات داده‌شده."""
        if length < 4:
            raise ValueError("طول رمز عبور باید حداقل ۴ کاراکتر باشد.")

        pools = []
        if use_lower:
            pools.append(self.LOWER)
        if use_upper:
            pools.append(self.UPPER)
        if use_digits:
            pools.append(self.DIGITS)
        if use_symbols:
            pools.append(self.SYMBOLS)

        if not pools:
            raise ValueError("حداقل یک نوع کاراکتر باید انتخاب شود.")

        # ابتدا یک کاراکتر از هر دسته‌ی انتخاب‌شده برمی‌داریم تا مطمئن شویم
        # همه‌ی انواع کاراکتر درخواستی حتماً در رمز عبور نهایی حضور دارند
        password_chars = [secrets.choice(pool) for pool in pools]

        all_chars = "".join(pools)
        remaining = length - len(password_chars)
        password_chars += [secrets.choice(all_chars) for _ in range(remaining)]

        # به‌هم‌ریختن ترتیب کاراکترها، تا کاراکترهای اجباری همیشه اول نباشند
        secrets.SystemRandom().shuffle(password_chars)

        return "".join(password_chars)

"""
مدل‌های داده (Domain Models).

- کالس Record یک کالس پایه (base class) است که بین همه‌ی چیزهایی که در
  صندوقچه ذخیره می‌شوند مشترک است (نمونه‌ای از وراثت / Inheritance).
- کالس PasswordEntry از Record ارث‌بری می‌کند و داده‌های مخصوص یک
  رمز عبور را اضافه می‌کند.
- ویژگی‌ها (attributes) به صورت خصوصی (private) نگه‌داری می‌شوند و فقط
  از طریق property ها در دسترس هستند، تا داده‌ی نامعتبر هرگز نتواند از
  بیرون کالس وارد شی‌ء شود (کپسوله‌سازی / Encapsulation).
"""

import uuid
from datetime import datetime


class Record:
    """کالس پایه برای هر چیزی که در صندوقچه ذخیره می‌شود."""

    def __init__(self, title: str):
        if not title.strip():
            raise ValueError("عنوان نمی‌تواند خالی باشد.")
        self._id = str(uuid.uuid4())
        self._title = title
        self._created_at = datetime.now().isoformat(timespec="seconds")

    @property
    def id(self) -> str:
        return self._id

    @property
    def title(self) -> str:
        return self._title

    @title.setter
    def title(self, value: str):
        if not value.strip():
            raise ValueError("عنوان نمی‌تواند خالی باشد.")
        self._title = value

    @property
    def created_at(self) -> str:
        return self._created_at

    def to_dict(self) -> dict:
        return {"id": self._id, "title": self._title, "created_at": self._created_at}

    @classmethod
    def from_dict(cls, data: dict):
        raise NotImplementedError("کالس‌های فرزند باید from_dict را پیاده‌سازی کنند.")

    def __repr__(self):
        return f"{self.__class__.__name__}(title={self._title!r})"


class PasswordEntry(Record):
    """یک رکورد ذخیره‌شده در صندوقچه (نام کاربری + رمز عبور). فرزند Record است."""

    def __init__(self, title: str, username: str, password: str):
        super().__init__(title)
        self._username = username
        self.password = password  # از طریق setter عبور می‌کند -> اعتبارسنجی می‌شود

    @property
    def username(self) -> str:
        return self._username

    @username.setter
    def username(self, value: str):
        if not value.strip():
            raise ValueError("نام کاربری نمی‌تواند خالی باشد.")
        self._username = value

    @property
    def password(self) -> str:
        return self._password

    @password.setter
    def password(self, value: str):
        if len(value) < 4:
            raise ValueError("رمز عبور باید حداقل ۴ کاراکتر باشد.")
        self._password = value

    def to_dict(self) -> dict:
        data = super().to_dict()
        data.update({"username": self._username, "password": self._password})
        return data

    @classmethod
    def from_dict(cls, data: dict):
        entry = cls(data["title"], data["username"], data["password"])
        entry._id = data["id"]
        entry._created_at = data["created_at"]
        return entry

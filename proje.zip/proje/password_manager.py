"""
منطق اصلی برنامه (Business Logic).

کالس PasswordManager لیست رکوردها را به صورت خصوصی نگه می‌دارد و اجازه
نمی‌دهد بقیه‌ی برنامه مستقیماً آن را تغییر دهند؛ فقط از طریق چند متد
مشخص می‌توان با آن کار کرد (کپسوله‌سازی). در داخل، این کالس با
Storage (که یک Singleton است) کار می‌کند تا همه‌ی بخش‌های برنامه همیشه
با یک صندوقچه‌ی مشترک کار کنند.
"""

from typing import List

from models import PasswordEntry
from storage import Storage


class PasswordManager:
    def __init__(self):
        self._storage = Storage()  # همیشه همان نمونه‌ی Singleton
        self._entries: List[PasswordEntry] = []

    # -- چرخه‌ی عمر -----------------------------------------------------
    def unlock(self, master_password: str) -> None:
        """باز کردن صندوقچه و بارگذاری رکوردها در حافظه."""
        self._storage.unlock(master_password)
        raw_entries = self._storage.load_entries()
        self._entries = [PasswordEntry.from_dict(d) for d in raw_entries]

    def vault_exists(self) -> bool:
        return self._storage.vault_exists()

    def _persist(self) -> None:
        """ذخیره‌ی وضعیت فعلی رکوردها روی دیسک."""
        self._storage.save_entries([e.to_dict() for e in self._entries])

    # -- عملیات CRUD (ایجاد/خواندن/به‌روزرسانی/حذف) ---------------------
    def add_entry(self, title: str, username: str, password: str) -> PasswordEntry:
        entry = PasswordEntry(title, username, password)
        self._entries.append(entry)
        self._persist()
        return entry

    def list_entries(self) -> List[PasswordEntry]:
        return list(self._entries)  # یک کپی برمی‌گردانیم تا وضعیت داخلی دستکاری نشود

    def find_by_title(self, title: str) -> List[PasswordEntry]:
        needle = title.lower()
        return [e for e in self._entries if needle in e.title.lower()]

    def update_password(self, entry_id: str, new_password: str) -> bool:
        for e in self._entries:
            if e.id == entry_id:
                e.password = new_password  # از setter عبور می‌کند -> اعتبارسنجی می‌شود
                self._persist()
                return True
        return False

    def delete_entry(self, entry_id: str) -> bool:
        before = len(self._entries)
        self._entries = [e for e in self._entries if e.id != entry_id]
        deleted = len(self._entries) != before
        if deleted:
            self._persist()
        return deleted
